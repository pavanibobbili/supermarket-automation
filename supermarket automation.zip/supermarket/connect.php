<?php
$connection=mysqli_connect("localhost","root","pavani123","supermarket");

if($connection)
{
echo "connection";
}
else
{
echo "error";
}
$FullName=mysqli_real_escape_string($connection,$_POST['uname']);
$Email=mysqli_real_escape_String($connection,$_POST['mail']);
$Quantity=mysqli_real_escape_String($connection,$_POST['quantity']);
$Number=mysqli_real_escape_String($connection,$_POST['num']);
$Address=mysqli_real_escape_String($connection,$_POST['address']);

echo "record inserted";

/*$query="CREATE TABLE Market( FULLNAME CHAR(30) NOT NULL,EMAIL VARCHAR(30) NOT NULL,Quantity VARCHAR(30) NOT NULL,NUMBER CHAR(30) NOT NULL,ADDRESS VARCHAR(30));";
if(mysqli_query($connection,$query))
{
echo "table created"."<br>";
}
else{
echo "error:".mysqli_error($connection);
}*/
$query1="INSERT INTO Market VALUES('$FullName','$Email','$Quantity','$Number','$Address');";
if(mysqli_query($connection,$query1))
{
	echo "record inserted";
}
else
{
	echo "error";
}
$query2="select * from Market;";
$check=mysqli_query($connection,$query2);
if(mysqli_num_rows($check))
{
	while($row=mysqli_fetch_assoc($check))
	{
		echo "";
	}
}
else{
	echo "";
}
echo "<a href=load.html>NEXT</a>";
?>

